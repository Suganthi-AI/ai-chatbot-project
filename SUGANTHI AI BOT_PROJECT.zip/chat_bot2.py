import time

print("Welcome to Office Application ChatBot!")
print("Let's help you prepare for internships, resumes, and job questions.\n")

while True:
    print("\nWhat do you want help with?")
    print("1. Create Resume")
    print("2. Prepare for Internship Questions")
    print("3. Exit")

    choice = input("Enter your choice (1/2/3): ")

    if choice == '1':
        name = input("What is your full name? ")
        year = input("Which year did you complete your graduation? ")
        degree = input("What is your qualification (e.g., MCA, BSc)? ")
        skill = input("Enter one key technical skill: ")

        print("\nGenerating Resume Summary...\n")
        time.sleep(2)
        print(f"Hi, I'm {name}. I completed my {degree} in {year}.")
        print(f"I am skilled in {skill} and currently looking for opportunities to grow in the IT field.")
        print("This summary can be used in your resume and introductions!\n")

    elif choice == '2':
        print("\nSample Internship Questions:")
        print("- What's your name?")
        print("- When did you complete your graduation?")
        print("- What are your technical skills?")
        print("- Why do you want this internship?")
        print("- Tell me about a project you’ve done.")

    elif choice == '3':
        print("Thank you for using the chatbot. All the best! 💖")
        break
    else:
        print("Invalid choice. Please select 1, 2, or 3.")